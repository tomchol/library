package ensta;
import com.ensta.librarymanager.model.*;
import com.ensta.librarymanager.dao.*;
import com.ensta.librarymanager.exception.DaoException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Some Unit test for Dao
 */
public class DaoTest
{
    @Test
    public void TestListAndCountMembers() throws DaoException {
        MembreDao MDao = MembreDaoImpl.getInstance();
        try {
            int nombreMembres = MDao.count();
            List<Membre> membres = MDao.getList();
            assertEquals(nombreMembres, membres.size());
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestCreateMemberAndGetById() throws DaoException {
        MembreDao MDao = MembreDaoImpl.getInstance();
        try {
            int id = MDao.create("Chollet", "Tom", "Paris", "tom.chollet.2022@ensta-paris.fr", "0611223344");
            Membre Tom = MDao.getById(id);
            assertEquals(Tom.getNom(), "Chollet");
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListAndCountBooks() throws DaoException {
        LivreDao LDao = LivreDaoImpl.getInstance();
        try {
            int nombreLivres = LDao.count();
            List<Livre> livres = LDao.getList();
            assertEquals(nombreLivres, livres.size());
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestCreateBookdAndGetById() throws DaoException {
        LivreDao LDao = LivreDaoImpl.getInstance();
        try {
            int id = LDao.create("La quete d'Ewilan","Pierre Bottero","978-542-46100");
            Livre Ewilan = LDao.getById(id);
            assertEquals("Pierre Bottero", Ewilan.getAuteur());
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListAndCountEmprunt() throws DaoException {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        try {
            int nombreEmprunts = EDao.count();
            List<Emprunt> emprunts = EDao.getList();
            assertEquals(nombreEmprunts, emprunts.size());
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListCurrentEmprunt() throws DaoException {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        try {
            List<Emprunt> emprunts = EDao.getListCurrent();
            assertEquals(emprunts.size(), 3); //Il y a 3 livres non rendus dans la base de données
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

}