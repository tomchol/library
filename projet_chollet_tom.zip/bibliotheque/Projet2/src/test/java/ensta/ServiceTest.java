package ensta;
import com.ensta.librarymanager.model.*;
import com.ensta.librarymanager.service.*;
import com.ensta.librarymanager.exception.ServiceException;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

/**
 * Some Unit test for Service
 */
public class ServiceTest
{
    @Test
    public void TestListAndCountMembers() throws ServiceException {
        MembreService MService = MembreServiceImpl.getInstance();
        try {
            int nombreMembres = MService.count();
            List<Membre> membres = MService.getList();
            assertEquals(nombreMembres, membres.size());
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestCreateMemberAndGetById() throws ServiceException {
        MembreService MService = MembreServiceImpl.getInstance();
        try {
            int id = MService.create("Chollet", "Tom", "Paris", "tom.chollet.2022@ensta-paris.fr", "0611223344");
            Membre Tom = MService.getById(id);
            assertEquals(Tom.getNom(), "CHOLLET");
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListAndCountBooks() throws ServiceException {
        LivreService LService = LivreServiceImpl.getInstance();
        try {
            int nombreLivres = LService.count();
            List<Livre> livres = LService.getList();
            assertEquals(nombreLivres, livres.size());
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestCreateBookdAndGetById() throws ServiceException {
        LivreService LService = LivreServiceImpl.getInstance();
        try {
            int id = LService.create("La quete d'Ewilan","Pierre Bottero","978-542-46100");
            Livre Ewilan = LService.getById(id);
            assertEquals("Pierre Bottero", Ewilan.getAuteur());
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListAndCountEmprunt() throws ServiceException {
        EmpruntService EService = EmpruntServiceImpl.getInstance();
        try {
            int nombreEmprunts = EService.count();
            List<Emprunt> emprunts = EService.getList();
            assertEquals(nombreEmprunts, emprunts.size());
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Test
    public void TestListCurrentEmprunt() throws ServiceException {
        EmpruntService EService = EmpruntServiceImpl.getInstance();
        try {
            List<Emprunt> emprunts = EService.getListCurrent();
            assertEquals(emprunts.size(), 3); //Il y a 3 livres non rendus dans la base de données
        } catch (ServiceException e)
        {
            System.out.println(e.getMessage());
        }
    }
}