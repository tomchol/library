package ensta;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Abonnement;
import java.time.LocalDate;
import org.junit.Test;

/**
 * Some Unit test for Modele
 */
public class ModeleTest
{
    // On effectue des tests d'affichage, le reste sont juste des get/set
	Membre Tom = new Membre(0,"Chollet","Tom","Résidence ENSTA","tom.chollet.2022@ensta-paris.fr","0611223344",Abonnement.PREMIUM);
	Livre Ewilan = new Livre(1,"La quete d'Ewilan", "Pierre Bottero", "this is the isbn");
    Emprunt e1 = new Emprunt(5,Tom,Ewilan,LocalDate.now(),LocalDate.now());

    @Test
    public void TestPrintMember()
    {
        System.out.println(Tom);
    }

    @Test
    public void TestPrintLivre()
    {
        System.out.println(Ewilan);
    }

    @Test
    public void TestPrintEmprunt()
    {
        System.out.println(e1);
    }



}