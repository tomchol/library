package com.ensta.librarymanager.service;

import com.ensta.librarymanager.model.*;
import com.ensta.librarymanager.dao.*;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.service.MembreService;
import com.ensta.librarymanager.service.EmpruntService;


import java.util.ArrayList;
import java.util.List;

public class MembreServiceImpl implements MembreService {
    // Singleton attribut et constructeur
    private static MembreServiceImpl instance = new MembreServiceImpl();

    private MembreServiceImpl(){}

    public static MembreServiceImpl getInstance(){
        if (instance == null){
            instance = new MembreServiceImpl();
        }
        return instance;
    }

    @Override
    public List<Membre> getList() throws ServiceException 
    {
        MembreDao MDao = MembreDaoImpl.getInstance();
        List<Membre> membres = new ArrayList<>();
        try {
            membres = MDao.getList();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return membres;
    }

    @Override
    public List<Membre> getListMembreEmpruntPossible() throws ServiceException
    {
        List<Membre> membres = new ArrayList<>();
        List<Membre> membresEmpruntPossible = new ArrayList<>();
        EmpruntService EService = EmpruntServiceImpl.getInstance();
        try {
            membres = getList();
            for (Membre membre : membres)
            {
                if (EService.isEmpruntPossible(membre)) membresEmpruntPossible.add(membre);
            }
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
        }
        return membresEmpruntPossible;
    }

    @Override
    public Membre getById(int id) throws ServiceException 
    {
        Membre membre = new Membre();
        MembreDao MDao = MembreDaoImpl.getInstance();
        try {
            membre = MDao.getById(id);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return membre;
    }

    @Override
    public int create(String nom, String prenom, String adresse, String email, String telephone) throws ServiceException
    {
        MembreDao MDao = MembreDaoImpl.getInstance();
        int id = -1;
        try {
            if (nom == "" | prenom == "")
            {
                throw new ServiceException("Nom ou prenom vide");
            }
            else {
                id = MDao.create(nom.toUpperCase(),prenom,adresse,email,telephone);
            }
        }  catch (DaoException |ServiceException e) {
            System.out.println(e.getMessage());
        }
        return id;
    }


    @Override
    public void update(Membre membre) throws ServiceException
    {
        MembreDao MDao = MembreDaoImpl.getInstance();
        try {
            if (membre.getNom() == "" || membre.getPrenom() == "")
            {
                throw new ServiceException("Nom ou prenom vide");
            }
            else {
                membre.setNom(membre.getNom().toUpperCase());
                MDao.update(membre);
            }
        } catch (DaoException e){
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public void delete(int id) throws ServiceException
    {
        MembreDao MDao = MembreDaoImpl.getInstance();
        try {
            MDao.delete(id);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public int count() throws ServiceException {
        MembreDao MDao = MembreDaoImpl.getInstance();
        int count = -1;
        try {
            count = MDao.count();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return count;
    }
}