package com.ensta.librarymanager.service;

import com.ensta.librarymanager.model.*;
import com.ensta.librarymanager.dao.*;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.service.LivreService;
import com.ensta.librarymanager.service.EmpruntService;


import java.util.ArrayList;
import java.util.List;

public class LivreServiceImpl implements LivreService {
    // Singleton attribut et constructeur
    private static LivreServiceImpl instance = new LivreServiceImpl();

    private LivreServiceImpl(){}

    public static LivreServiceImpl getInstance(){
        if (instance == null){
            instance = new LivreServiceImpl();
        }
        return instance;
    }

    @Override
    public List<Livre> getList() throws ServiceException
    {
        LivreDao LDao = LivreDaoImpl.getInstance();
        List<Livre> livres = new ArrayList<>();
        try {
            livres = LDao.getList();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return livres;
    }

    @Override
    public List<Livre> getListDispo() throws ServiceException
    {
        List<Livre> livres = new ArrayList<>();
        List<Livre> livresPossible = new ArrayList<>();
        EmpruntService EService = EmpruntServiceImpl.getInstance();
        try {
            livres = getList();
            for (Livre livre : livres)
            {
                if (EService.isLivreDispo(livre.getId())) livresPossible.add(livre);
            }
        } catch (ServiceException e) {
            System.out.println(e.getMessage());
        }
        return livresPossible;
    }

    @Override
    public Livre getById(int id) throws ServiceException
    {
        Livre livre = new Livre();
        LivreDao LDao = LivreDaoImpl.getInstance();
        try {
            livre = LDao.getById(id);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return livre;
    }

    @Override
    public int create(String titre, String auteur, String isbn) throws ServiceException
    {
        LivreDao LDao = LivreDaoImpl.getInstance();
        int id = -1;
        try {
            if (titre == "")
            {
                throw new ServiceException("Titre vide");
            }
            else {
                id = LDao.create(titre,auteur,isbn);
            }
        }  catch (DaoException |ServiceException e) {
            System.out.println(e.getMessage());
        }
        return id;
    }


    @Override
    public void update(Livre livre) throws ServiceException
    {
        LivreDao LDao = LivreDaoImpl.getInstance();
        try {
            if (livre.getTitre() == "")
            {
                throw new ServiceException("Titre vide");
            }
            else {
                LDao.update(livre);
            }
        } catch (DaoException e){
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public void delete(int id) throws ServiceException
    {
        LivreDao LDao = LivreDaoImpl.getInstance();
        try {
            LDao.delete(id);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public int count() throws ServiceException {
        LivreDao LDao = LivreDaoImpl.getInstance();
        int count = -1;
        try {
            count = LDao.count();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return count;
    }
}