package com.ensta.librarymanager.model;
import java.time.LocalDate;

public class Emprunt
{
	private int id;
	private Membre Membre;
	private Livre Livre;
	private LocalDate dateEmprunt;
	private LocalDate dateRetour;

    public Emprunt() {
	}

	public Emprunt(int id, Membre Membre, Livre Livre, LocalDate dateEmprunt, LocalDate dateRetour) {
		this.id = id;
		this.Membre = Membre;
		this.Livre = Livre;
		this.dateEmprunt = dateEmprunt;
		this.dateRetour = dateRetour;
	}

	public int getId() {
		return id;
	}
	public Membre getMembre() {
		return Membre;
	}
	public Livre getLivre() {
		return Livre;
	}
	public LocalDate getDateEmprunt() {
		return dateEmprunt;
	}
	public LocalDate getDateRetour() {
		return dateRetour;
	}


	public void setId(int id) {
		this.id = id;
	}
	public void setMembre(Membre Membre) {
		this.Membre = Membre;
	}
	public void setLivre(Livre Livre) {
		this.Livre = Livre;
	}
    public void setDateEmprunt(LocalDate dateEmprunt) {
		this.dateEmprunt = dateEmprunt;
	}
	public void setDateRetour(LocalDate dateRetour) {
		this.dateRetour = dateRetour;
	}

	@Override
	public String toString() {
		return "Emprunt : id=" + id + ", Membre=(" + Membre + "); Livre=(" + Livre +
				"); dateEmprunt=" + dateEmprunt +"; dateRetour=" + dateRetour;
	}
}