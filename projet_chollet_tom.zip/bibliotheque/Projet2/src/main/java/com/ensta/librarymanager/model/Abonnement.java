package com.ensta.librarymanager.model;


public enum Abonnement{
	BASIC, PREMIUM, VIP
}