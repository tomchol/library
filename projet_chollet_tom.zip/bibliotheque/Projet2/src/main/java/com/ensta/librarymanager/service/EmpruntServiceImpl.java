package com.ensta.librarymanager.service;

import java.time.LocalDate;
import com.ensta.librarymanager.model.*;
import com.ensta.librarymanager.dao.*;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.exception.ServiceException;
import com.ensta.librarymanager.service.EmpruntService;

import java.util.ArrayList;
import java.util.List;

public class EmpruntServiceImpl implements EmpruntService {
    // Singleton attribut et constructeur
    private static EmpruntServiceImpl instance = new EmpruntServiceImpl();

    private EmpruntServiceImpl(){}

    public static EmpruntServiceImpl getInstance(){
        if (instance == null){
            instance = new EmpruntServiceImpl();
        }
        return instance;
    }

    @Override
    public List<Emprunt> getList() throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EDao.getList();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> getListCurrent() throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EDao.getListCurrent();
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> getListCurrentByMembre(int idMembre) throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EDao.getListCurrentByMembre(idMembre);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> getListCurrentByLivre(int idLivre) throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        List<Emprunt> emprunts = new ArrayList<>();
        try {
            emprunts = EDao.getListCurrentByLivre(idLivre);
        } catch (DaoException e) {
            System.out.println(e.getMessage());
        }
        return emprunts;
    }

    @Override
    public Emprunt getById(int id) throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        Emprunt emp = new Emprunt();
        try {
            emp = EDao.getById(id);
        }
        catch (DaoException e){
            System.out.println(e.getMessage());
        }
        return emp;
    }

    @Override
    public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        try {
            EDao.create(idMembre, idLivre, dateEmprunt);
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void returnBook(int id) throws ServiceException
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        Emprunt emp = new Emprunt();
        try {
            emp = EDao.getById(id);
            emp.setDateRetour(LocalDate.now());
            EDao.update(emp);
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
    }

       
    @Override
    public int count() throws ServiceException 
    {
        EmpruntDao EDao = EmpruntDaoImpl.getInstance();
        int i = -1;
        try {
            i = EDao.count();
        } catch (DaoException e)
        {
            System.out.println(e.getMessage());
        }
        return i;
    }

    @Override
    public boolean isLivreDispo(int idLivre) throws ServiceException
    {
        List<Emprunt> emprunts = getListCurrentByLivre(idLivre);
        for (Emprunt emp : emprunts)
        {
            if (emp.getDateRetour() == null)
                return false;
        }
        return true;
    }

    @Override
    public boolean isEmpruntPossible(Membre membre) throws ServiceException
    {
        List<Emprunt> emprunts = getListCurrentByMembre(membre.getId());
        if (emprunts.size() >= membre.getLimitAbonnement()) return false;
        return true;
    }
}