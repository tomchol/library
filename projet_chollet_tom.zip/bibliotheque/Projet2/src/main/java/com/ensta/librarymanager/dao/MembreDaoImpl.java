package com.ensta.librarymanager.dao;

import java.util.List;
import java.util.ArrayList;
import com.ensta.librarymanager.dao.MembreDao;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.model.Abonnement;
import com.ensta.librarymanager.persistence.ConnectionManager;
import java.sql.*;

public class MembreDaoImpl implements MembreDao {
    // Singleton attribut et constructeur
    private static MembreDaoImpl instance;

    private MembreDaoImpl(){}

    public static MembreDaoImpl getInstance(){
        if (instance == null){
            instance = new MembreDaoImpl();
        }
        return instance;
    }

    //Commandes SQL

    private static final String SELECT_ALL_QUERY =  "SELECT * FROM membre ORDER BY nom, prenom;";
    private static final String SELECT_ONE_QUERY = "SELECT * FROM membre WHERE id = ?;";
    private static final String CREATE_QUERY = "INSERT INTO membre(nom,prenom,adresse,email,telephone,abonnement) VALUES (?,?,?,?,?,?);";
    private static final String UPDATE_QUERY = "UPDATE membre SET nom=?, prenom=?, adresse=?, email=?, telephone=?, abonnement=? WHERE id=?;";
    private static final String DELETE_QUERY = "DELETE FROM membre WHERE id=?;";
    private static final String COUNT = "SELECT COUNT(id) AS count FROM membre;";

    @Override
    public List<Membre> getList() throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Membre> listMembres = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            result = preparedStatement.executeQuery();

            while(result.next()){
                listMembres.add(new Membre(result.getInt("id"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les membres",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return listMembres;
    }


    @Override
    public Membre getById(int id) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;
        Membre membre = new Membre();

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ONE_QUERY);
            preparedStatement.setInt(1,id);
            result = preparedStatement.executeQuery();

            if (result.next()){
                membre = new Membre(result.getInt("id"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement")));
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture du membre d'id :" + id,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return membre;
    }

    @Override
    public int create(String nom, String prenom, String adresse, String email, String telephone) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;
        int id = -1;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(CREATE_QUERY, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1,nom);
            preparedStatement.setString(2,prenom);
            preparedStatement.setString(3,adresse);
            preparedStatement.setString(4,email);
            preparedStatement.setString(5,telephone);
            preparedStatement.setString(6,"BASIC");
            
            preparedStatement.executeUpdate();
            result = preparedStatement.getGeneratedKeys();
            
            if (result.next()){
                id = result.getInt(1);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la création du membre",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return id;
    }

    @Override
    public void update(Membre membre) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(UPDATE_QUERY);
            preparedStatement.setString(1,membre.getNom());
            preparedStatement.setString(2,membre.getPrenom());
            preparedStatement.setString(3,membre.getAdresse());
            preparedStatement.setString(4,membre.getEmail());
            preparedStatement.setString(5,membre.getTelephone());
            preparedStatement.setString(6,membre.getAbonnement().name());
            preparedStatement.setInt(7, membre.getId());

            preparedStatement.executeUpdate();

        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la mise à jour du membre d'id :" + membre.getId(),e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(DELETE_QUERY);
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la supression du membre d'id :" +id,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
	
    @Override
    public int count() throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(COUNT);
            
            result = preparedStatement.executeQuery();
            
            if (result.next()){
                return result.getInt("count");
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors du comptage du nombre de membres",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return 0;
    }
}