package com.ensta.librarymanager.dao;

import java.util.List;
import java.util.ArrayList;
import com.ensta.librarymanager.dao.LivreDao;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Abonnement;
import com.ensta.librarymanager.persistence.ConnectionManager;
import java.sql.*;

public class LivreDaoImpl implements LivreDao {
    // Singleton attribut et constructeur
    private static LivreDaoImpl instance;

    private LivreDaoImpl(){}

    public static LivreDaoImpl getInstance(){
        if (instance == null){
            instance = new LivreDaoImpl();
        }
        return instance;
    }

    //Commandes SQL

    private static final String SELECT_ALL_QUERY =  "SELECT * FROM livre;";
    private static final String SELECT_ONE_QUERY = "SELECT * FROM livre WHERE id = ?;";
    private static final String CREATE_QUERY = "INSERT INTO livre(titre,auteur,isbn) VALUES (?,?,?);";
    private static final String UPDATE_QUERY = "UPDATE livre SET titre=?, auteur=?, isbn=? WHERE id=?;";
    private static final String DELETE_QUERY = "DELETE FROM livre WHERE id=?;";
    private static final String COUNT = "SELECT COUNT(id) AS count FROM livre;";

    @Override
    public List<Livre> getList() throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Livre> listLivres = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            result = preparedStatement.executeQuery();

            while(result.next()){
                listLivres.add(new Livre(result.getInt("id"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les livres",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return listLivres;
    }


    @Override
    public Livre getById(int id) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;
        Livre livre = new Livre();

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ONE_QUERY);
            preparedStatement.setInt(1,id);
            result = preparedStatement.executeQuery();

            if (result.next()){
                livre = new Livre(result.getInt("id"),result.getString("titre"),result.getString("auteur"),result.getString("isbn"));
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture du livre d'id :" + id,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return livre;
    }

    @Override
    public int create(String titre, String auteur, String isbn) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;
        int id = -1;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(CREATE_QUERY, Statement.RETURN_GENERATED_KEYS);
            preparedStatement.setString(1,titre);
            preparedStatement.setString(2,auteur);
            preparedStatement.setString(3,isbn);
            
            preparedStatement.executeUpdate();
            result = preparedStatement.getGeneratedKeys();
            
            if (result.next()){
                id = result.getInt(1);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la création du livre",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }


        }
        return id;
    }

    @Override
    public void update(Livre livre) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(UPDATE_QUERY);
            preparedStatement.setString(1,livre.getTitre());
            preparedStatement.setString(2,livre.getAuteur());
            preparedStatement.setString(3,livre.getIsbn());
            preparedStatement.setInt(4, livre.getId());

            preparedStatement.executeUpdate();

        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la mise à jour du livre d'id :" + livre.getId(),e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(DELETE_QUERY);
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la supression du livre d'id :" +id,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
	
    @Override
    public int count() throws DaoException
    {
        Connection connection = null;
        ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(COUNT);
            
            result = preparedStatement.executeQuery();
            
            if (result.next()){
                return result.getInt("count");
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors du contage du nombre de livres",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return 0;
    }
}