package com.ensta.librarymanager.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.ArrayList;
import com.ensta.librarymanager.dao.EmpruntDao;
import com.ensta.librarymanager.exception.DaoException;
import com.ensta.librarymanager.model.Emprunt;
import com.ensta.librarymanager.model.Livre;
import com.ensta.librarymanager.model.Membre;
import com.ensta.librarymanager.model.Abonnement;
import com.ensta.librarymanager.persistence.ConnectionManager;
import java.sql.*;

public class EmpruntDaoImpl implements EmpruntDao {
    // Singleton attribut et constructeur
    private static EmpruntDaoImpl instance;

    private EmpruntDaoImpl(){}

    public static EmpruntDaoImpl getInstance(){
        if (instance == null){
            instance = new EmpruntDaoImpl();
        }
        return instance;
    }

    //Commandes SQL

    private static final String SELECT_ALL_QUERY =  "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre ORDER BY dateRetour DESC;";
    private static final String SELECT_ALL_NON_RETURN = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL;";
    private static final String SELECT_NON_RETURN_BY_MEMBER = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL AND membre.id = ?;";
    private static final String SELECT_NON_RETURN_BY_BOOK = "SELECT e.id AS id, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE dateRetour IS NULL AND livre.id = ?;";
    private static final String SELECT_ONE_QUERY = "SELECT e.id AS idEmprunt, idMembre, nom, prenom, adresse, email, telephone, abonnement, idLivre, titre, auteur, isbn, dateEmprunt, dateRetour FROM emprunt AS e INNER JOIN membre ON membre.id = e.idMembre INNER JOIN livre ON livre.id = e.idLivre WHERE e.id = ?;";
    private static final String CREATE_QUERY = "INSERT INTO emprunt(idMembre, idLivre, dateEmprunt, dateRetour) VALUES (?, ?, ?, ?);";
	private static final String UPDATE_QUERY = "UPDATE emprunt SET idMembre = ?, idLivre = ?, dateEmprunt = ?, dateRetour = ? WHERE id = ?;";
	private static final String COUNT = "SELECT COUNT(id) AS count FROM emprunt;";

    @Override
    public List<Emprunt> getList() throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Emprunt> listEmprunts = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_QUERY);
            result = preparedStatement.executeQuery();

            while(result.next()){
                Emprunt emp = new Emprunt();
				emp.setId(result.getInt("id"));
				emp.setMembre(new Membre(result.getInt("idMembre"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
				emp.setLivre(new Livre(result.getInt("idLivre"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
				emp.setDateEmprunt(result.getDate("dateEmprunt").toLocalDate());
				if (result.getDate("dateRetour")!=null) emp.setDateRetour(result.getDate("dateRetour").toLocalDate());
				listEmprunts.add(emp);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les emprunts",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return listEmprunts;
    }

    @Override
    public List<Emprunt> getListCurrent() throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Emprunt> listEmprunts = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ALL_NON_RETURN);
            result = preparedStatement.executeQuery();

            while(result.next()){
                Emprunt emp = new Emprunt();
				emp.setId(result.getInt("id"));
				emp.setMembre(new Membre(result.getInt("idMembre"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
				emp.setLivre(new Livre(result.getInt("idLivre"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
				emp.setDateEmprunt(result.getDate("dateEmprunt").toLocalDate());
				listEmprunts.add(emp);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les emprunts pas encore rendus",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return listEmprunts;
    }

    @Override
    public List<Emprunt> getListCurrentByMembre(int idMembre) throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Emprunt> listEmprunts = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_NON_RETURN_BY_MEMBER);
			preparedStatement.setInt(1,idMembre);
            result = preparedStatement.executeQuery();

            while(result.next()){
                Emprunt emp = new Emprunt();
				emp.setId(result.getInt("id"));
				emp.setMembre(new Membre(result.getInt("idMembre"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
				emp.setLivre(new Livre(result.getInt("idLivre"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
				emp.setDateEmprunt(result.getDate("dateEmprunt").toLocalDate());
				listEmprunts.add(emp);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les emprunts non rendu par le membre d'id :"+idMembre,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return listEmprunts;
    }

    @Override
    public List<Emprunt> getListCurrentByLivre(int idLivre) throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ArrayList<Emprunt> listEmprunts = new ArrayList<>();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_NON_RETURN_BY_BOOK);
			preparedStatement.setInt(1,idLivre);
            result = preparedStatement.executeQuery();

            while(result.next()){
                Emprunt emp = new Emprunt();
				emp.setId(result.getInt("id"));
				emp.setMembre(new Membre(result.getInt("idMembre"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
				emp.setLivre(new Livre(result.getInt("idLivre"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
				emp.setDateEmprunt(result.getDate("dateEmprunt").toLocalDate());
				listEmprunts.add(emp);
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de tous les emprunts non rendu pour le livre d'id :"+idLivre,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return listEmprunts;
    }

    @Override
    public Emprunt getById(int id) throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;
        Emprunt emp = new Emprunt();

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(SELECT_ONE_QUERY);
            preparedStatement.setInt(1,id);
            result = preparedStatement.executeQuery();

            if (result.next()){
				emp.setId(result.getInt("id"));
				emp.setMembre(new Membre(result.getInt("idMembre"),result.getString("nom"),result.getString("prenom"),result.getString("adresse"),result.getString("email"),result.getString("telephone"),Abonnement.valueOf(result.getString("abonnement"))));
				emp.setLivre(new Livre(result.getInt("idLivre"),result.getString("titre"),result.getString("auteur"),result.getString("isbn")));
				emp.setDateEmprunt(result.getDate("dateEmprunt").toLocalDate());
				if (result.getDate("dateRetour")!=null) emp.setDateRetour(result.getDate("dateRetour").toLocalDate());
				return emp;
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la lecture de l'emprunt d'id :" + id,e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return emp;
    }

    @Override
    public void create(int idMembre, int idLivre, LocalDate dateEmprunt) throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(CREATE_QUERY);
            preparedStatement.setInt(1,idMembre);
            preparedStatement.setInt(2,idLivre);
            preparedStatement.setDate(3,Date.valueOf(dateEmprunt));
			preparedStatement.setDate(4,null);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la création du livre",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void update(Emprunt emprunt) throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(UPDATE_QUERY);
			Membre membre = emprunt.getMembre();
			Livre livre = emprunt.getLivre();
            preparedStatement.setInt(1,membre.getId());
            preparedStatement.setInt(2,livre.getId());
            preparedStatement.setDate(3,Date.valueOf(emprunt.getDateEmprunt()));
            preparedStatement.setDate(4, Date.valueOf(emprunt.getDateRetour()));

            preparedStatement.executeUpdate();

        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors de la mise à jour de l'emprunt d'id :" + emprunt.getId(),e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
	
    @Override
    public int count() throws DaoException
    {
        Connection connection = null;
		ConnectionManager connectionManager = new ConnectionManager();
        ResultSet result = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = connectionManager.getConnection();
            preparedStatement = connection.prepareStatement(COUNT);
            
            result = preparedStatement.executeQuery();
            
            if (result.next()){
                return result.getInt("count");
            }
        } catch (SQLException e) 
        {
            throw new DaoException("Problème lors du contage du nombre des emprunts",e);
        } catch (Exception e)
        {
            throw new DaoException("Problème lors de la connection",e);
        } finally
        {
            try{
                connection.close();
            } catch (Exception e)
            {
                throw new DaoException("Problème fermeture de la connection",e);
            }

            try{
                preparedStatement.close();
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        }
        return 0;
    }
}