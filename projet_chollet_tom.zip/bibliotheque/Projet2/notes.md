# CNRS-AIST Joint Robotics Laboratory
## National Institute of Advanced Industrial Science and Technology (AIST)

# Presentation :

## Background
My name is Tom Chollet, I am 21 years old, and currently I am in second year at the french Engineering school ENSTA Paris. I think I always wanted to be an Engineer, so I specialised as soon as I could to take courses about Sciences of the Engineer in highschool. I then graduated from the french baccalaureate with the highest honors in 2017.

After that I went to what we call the "Preparatory classes". Mine was specialized in Physics And Technology. This is two or three years of very intense preparation in order to get ready for the examinations that you have to pass if you want to access the best french Engineering schools.

## Currently
I am currently studying at ENSTA Paris, my second year specialization is Computer Science. I am following courses about automatization, learning and programmation in many ways. 

### Teaching in Preparatory Class
This year, one of my former teacher from when I was in preparatory class contacted me to come back and interrogate first year student on subjects about Engineering science two hours a week. This is as been a very interesting opportunity so far, and I thing because I was in their position only 3 years ago I can really help them understand how to work efficiently and how to deal with those two years in general.

### Perseus
I also work on a very interesting subject : The Perseus Project. This is a nationnal project for students en Engineering school and it is supervised by the CNES (Nationnal Center of Spacial Etudes). In this project, student have the objective of building a reusable launcher like what Space X is doing. 

I am part of a team which is designing a moto pump that will be used in the dream "dream on". We aare the first team working onthe launcher because he will be launch in 3 years. In this project I am the lead designer regarding the technical solution because thanks to my preparatory class I am familiar with technical drawing so I was able to draw a solution for our pump. This is such an interesting project, there is a lot to do because we started with nothing and very fiew knwoledge about how a moto pump is supposed to work but we are currently doing the CAO of the pump.
Our team as been rewarded by the CNES for being the "Most Inovating Project" of the year

# Why me ?

Sincerely I think I am the most motivated student you can find. I really want to persue on the Robotics field of study because it interest me a lot. Moreover I am really attracted by the Japanese Culture. Regarding this, working in your laboratory motivates me a lot. 
I dont think I would like to stop my career in your Laboratory after a single stage so I will do my best and prove you that I am a usefull element and that you shoud continu working with me. 

I have all the competences needed for this project.

I am looking to do my research internship with Professor Philippe Martin from the CAS at Mines Paritech on a drone project. I would be working on optimization of the drone stabilization algorithms. 

# Questions ?

#### I have seen all the projects that there is at the CNRS-AIST Joint Robotics Laboratory, is this optimization project part of one of those ?

#### Some student at ENSTA Paris did a course about non linear optimization, would you like me to work on the notion with their notes to come with a better background ?

#### You asked for experience using Matlab and C++, what is this for ?

#### What do you mean by avoinding kinematic singularities

### More personnal questions

#### I was wondering what pushed you to apply for this laboratory for your PhD researches ?

### More tecnical question

#### Is this internship paid? How much could I be expecting?

#### Is housing at my own expense? Do AIST have contacts to help me find an appartment?